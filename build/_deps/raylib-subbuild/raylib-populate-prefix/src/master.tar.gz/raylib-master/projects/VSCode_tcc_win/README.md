How to use
1. Rename Folder
2. open workspace (main.code-workspace)
3. edit Makefile to include your files
4. F5 and choose "build & run"
